import 'package:flutter/material.dart';

class SearchPageModel extends ChangeNotifier {

}
