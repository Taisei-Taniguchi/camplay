def firebase_sdk_version!()
  '7.3.0'
end
